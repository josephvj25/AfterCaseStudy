﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FacilitesFeedbackBackendV1.Models;
using System.Net;

namespace FacilitesFeedbackBackendV1.Controllers
{
    public class AdminController : Controller
    {
        AdminEntities db = new AdminEntities();
        // GET: Admin
        [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        // GET: Feedbacks
        public ActionResult Index()
        {
           
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                return View();
            }
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult Facilities()
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                var item = db.Facilities.ToList();
                return View(item);
            }
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult FacilitiesCreate()
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               var item = new Facility();
               return View(item);
           }
       }
       [HttpPost]
       public ActionResult FacilitiesCreate(Facility item)
       {
           db.Facilities.Add(item);
           db.SaveChanges();

           return RedirectToAction("QuestionCreateList/" + item.FacilityID);

       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult FacilitiesEdit(int id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {

               var item = db.Facilities.Where(m => m.FacilityID.Equals(id)).FirstOrDefault();


               return View(item);
           }
       }
        [HttpPost]
        public ActionResult FacilitiesEdit(Facility item)
       {
           if (item == null)
               return new HttpStatusCodeResult(HttpStatusCode.BadRequest, "Bad request");

           var old_item = db.Facilities.Where(m => m.FacilityID.Equals(item.FacilityID)).FirstOrDefault();
           old_item.FacilityName = item.FacilityName;
           db.SaveChanges();
           return RedirectToAction("Facilities");
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult FacilitiesDelete(int id)
        {
            //if (id == 0)
            //{
            //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest, "Bad Request");
            //}
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                var item = db.Facilities.Where(m => m.FacilityID.Equals(id)).FirstOrDefault();
                db.Facilities.Remove(item);
                db.SaveChanges();
                return RedirectToAction("Facilities");
            }
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult QuestionCreateList(int id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {

               var item = new CreateQuestion();
               item.FacilityID = id;


               return View(item);
           }

       }
        [HttpPost]
        public ActionResult QuestionCreateList(CreateQuestion item)
        {
            if (item == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest, "Bad Request");
            if(item.QuestionList==null)
                return RedirectToAction("QuestionDetails/" + item.FacilityID);
            if (true)
            {
                foreach (var i in item.QuestionList)
                {
                    i.FacilityID = item.FacilityID;
                    if (i.Question1 != null)
                    {
                        db.Questions.Add(i);
                    }


                }
                db.SaveChanges();
            }
            return RedirectToAction("QuestionDetails/"+item.FacilityID);
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult QuestionDetails(int id)
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                var item = db.Questions.Where(m => m.FacilityID.Equals(id));
                @ViewBag.FacilityID = id;
                @ViewBag.FacilityName = db.Facilities.Where(m => m.FacilityID.Equals(id)).FirstOrDefault().FacilityName;
                return View(item);
            }
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult QuestionDelete(int id)
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                var item = db.Questions.Where(m => m.QuestionID.Equals(id)).FirstOrDefault();
                //var ratings = db.Ratings.Where(m => m.QuestionID.Equals(id));
                //if (ratings != null)
                    //foreach (var r in ratings)
                    //{
                    //    db.Ratings.Remove(r);
                    //}
                db.Questions.Remove(item);
                try
                {
                    db.SaveChanges();
                    return RedirectToAction("QuestionDetails/" + item.FacilityID);
                }

                catch { return RedirectToAction("QuestionDetails/" + item.FacilityID); }
            }
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult QuestionEdit(int id,string question)
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                var item = db.Questions.Where(m => m.QuestionID.Equals(id)).FirstOrDefault();
                item.Question1 = question;
                db.SaveChanges();
                return RedirectToAction("QuestionDetails/" + item.FacilityID);
            }
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult Locations()
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               if(TempData["message"] != null)
               {
                   @ViewBag.Message = TempData["message"].ToString();
               }
               
               var item = db.Locations.ToList();
               return View(item);
           }
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult LocationsCreate()
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               Location item = new Location();
               return View(item);
           }

       }
        [HttpPost]
        public ActionResult LocationsCreate(Location item)
       {

            db.Locations.Add(item);
            db.SaveChanges();
            return RedirectToAction("Locations");
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult LocationsDelete(int id)
        {
            @ViewBag.Message = "";
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                var item = db.Locations.Where(m => m.LocationID.Equals(id)).FirstOrDefault();
                db.Locations.Remove(item);
                try
                {
                    db.SaveChanges();
                    return RedirectToAction("Locations");
                }
                catch
                {
                    TempData["message"] = "Selected Location contains dependencies";
                    
                    return RedirectToAction("Locations");
                }
            }
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult LocationsEdit(int id)
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                var item = db.Locations.Where(m => m.LocationID.Equals(id)).FirstOrDefault();

                return View(item);
            }
        }
        [HttpPost]
        public ActionResult LocationsEdit(Location item)
        {
            var old_item = db.Locations.Where(m => m.LocationID.Equals(item.LocationID)).FirstOrDefault();
            old_item.LocationName = item.LocationName;
            old_item.LocationCity = item.LocationCity;
            old_item.LocationCountry = item.LocationCountry;
            old_item.LocationZipCode = item.LocationZipCode;
            db.SaveChanges();
            return RedirectToAction("Locations");
        }
        //public ActionResult Buildings()
        //{
        //    var item = db.Buildings.ToList();
        //    return View(item);
        //}
        [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult Buildings(int? id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {

               IEnumerable<Building> item;

               if (id == null)
               {
                   @ViewBag.LocationID = "";
                   item = db.Buildings.ToList();
               }
               else
               {

                   int iid = Convert.ToInt32(id);
                   @ViewBag.LocationID = iid;
                   item = db.Buildings.Where(m => m.LocationID.Equals(iid));

               }

               return View(item);
           }
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult BuildingsCreate(int? id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               CreateBuilding item = new CreateBuilding();

               //var loc = db.Locations.ToList();
               item.LocationList = db.Locations.Select(r => new SelectListItem
               {
                   Value = r.LocationID.ToString(),
                   Text = r.LocationName,
               });

               if (id != null)
               {
                   item.LocationID = Convert.ToInt32(id);
               }
               return View(item);
           }
       }
       [HttpPost]
       public ActionResult BuildingsCreate(Building item)
       {
           db.Buildings.Add(item);
           db.SaveChanges();
           return RedirectToAction("Buildings/"+item.LocationID);
       }
        public ActionResult BuildingsDelete(int id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               var item = db.Buildings.Where(m => m.BuildingID.Equals(id)).FirstOrDefault();

               db.Buildings.Remove(item);
               db.SaveChanges();
               return RedirectToAction("Buildings/" + item.LocationID);
           }
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult BuildingsEdit(int id)
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                CreateBuilding item = new CreateBuilding();

                //var loc = db.Locations.ToList();
                item.LocationList = db.Locations.Select(r => new SelectListItem
                {
                    Value = r.LocationID.ToString(),
                    Text = r.LocationName,
                });

                var data_item = db.Buildings.Where(m => m.BuildingID.Equals(id)).FirstOrDefault();
                item.BuildingID = data_item.BuildingID;
                item.BuildingName = data_item.BuildingName;
                item.LocationID = data_item.LocationID;

                db.SaveChanges();
                return View(item);
            }
        }
        [HttpPost]
        public ActionResult BuildingsEdit(Building item)
        {
            var old_item = db.Buildings.Where(m => m.BuildingID.Equals(item.BuildingID)).FirstOrDefault();
            old_item.BuildingName = item.BuildingName;
            old_item.LocationID = item.LocationID;
            db.SaveChanges();
            return RedirectToAction("Buildings/" + item.LocationID);
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult Floors(int? id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               IEnumerable<Floor> item;

               @ViewBag.LocationID = "";
               if (id == null)
               {

                   item = db.Floors.ToList();
               }
               else
               {
                   @ViewBag.LocationID = Convert.ToInt32(id);
                   int iid = Convert.ToInt32(id);
                   item = db.Floors.Where(m => m.BuildingID.Equals(iid));

               }
               return View(item);
           }
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult FloorsCreate(int? id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               CreateFloor item = new CreateFloor();
               item.LocationList = db.Locations.Select(r => new SelectListItem
               {
                   Value = r.LocationID.ToString(),
                   Text = r.LocationName,
               });
               item.BuildingList = db.Buildings.Select(r => new SelectListItem
               {
                   Value = r.BuildingID.ToString(),
                   Text = r.BuildingName
               });

               if (id != null)
               {
                   item.BuildingID = Convert.ToInt32(id);
               }
               return View(item);
           }
           
       }
       [HttpPost]
       public ActionResult FloorsCreate(Floor item)
       {

           db.Floors.Add(item);
           db.SaveChanges();
           return RedirectToAction("Floors/"+item.BuildingID);
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult Users()
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               var item = db.Users.ToList();
               return View(item);
           }
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult UsersCreate()
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               User item = new User();

               return View(item);
           }
       }
       [HttpPost]
       public ActionResult UsersCreate(User item)
       {

           if (ModelState.IsValid)
           {
               if (item.UserRole == null)
               {
                   item.UserRole = "Associate";
               }
               db.Users.Add(item);

               if (item.UserRole != "Associate")
               {
                   SupervisorDetail sd = new SupervisorDetail();
                   sd.UserID = item.UserID;
                   sd.SupervisorLevel = item.UserRole;
                   db.SupervisorDetails.Add(sd);
               }


               db.SaveChanges();
               return RedirectToAction("Users");
           }
           else
               return View();
           
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult UsersEdit(string id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               var item = db.Users.Where(m => m.UserID.Equals(id)).FirstOrDefault();

               return View(item);
           }
       }

       [HttpPost]
        public ActionResult UsersEdit(User item)
       {
           if(ModelState.IsValid)
           {
               var user = db.Users.Where(m => m.UserID.Equals(item.UserID)).FirstOrDefault();
               if(user.UserRole != "Associate")
               {
                   var sup = db.SupervisorDetails.Where(m => m.UserID.Equals(item.UserID)).FirstOrDefault();
                   sup.SupervisorLevel = item.UserRole;
                   try
                   {
                       db.SaveChanges();
                   }
                   catch
                   { }
               }
               else if(item.UserRole!="Associate")
               {
                   SupervisorDetail sd = new SupervisorDetail();
                   sd.UserID = item.UserID;
                   sd.SupervisorLevel = item.UserRole;
                   db.SupervisorDetails.Add(sd);
                   try
                   {
                       db.SaveChanges();
                   }
                   catch
                   { }
               }
               user.UserName = item.UserName;
               user.UserPhoneNo = item.UserPhoneNo;
               user.UserRole = item.UserRole;
               try
               {
                   db.SaveChanges();
               }
               catch
               {

               }
               return RedirectToAction("Users", "Admin");
           }
           else
               return View();
           
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult FacilityUnits(int id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               var item = db.Units.Where(m => m.FloorID.Equals(id));
               @ViewBag.FloorID = id;
               @ViewBag.BuildingID = db.Floors.Where(m => m.FloorID.Equals(id)).FirstOrDefault().BuildingID;
               return View(item);
           }
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult FacilityUnitsCreate(int id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               CreateUnit item = new CreateUnit();

               item.BaseSupervisorList = db.SupervisorDetails.Where(m => m.SupervisorLevel.Equals("BaseSupervisor")).Select(r => new SelectListItem
               {
                   Value = r.UserID.ToString(),
                   Text = r.User.UserName
               });
               item.BuildingList = db.Buildings.Select(r => new SelectListItem
               {
                   Value = r.BuildingID.ToString(),
                   Text = r.BuildingName
               });

               item.FacilityList = db.Facilities.Select(r => new SelectListItem
               {
                   Value = r.FacilityID.ToString(),
                   Text = r.FacilityName
               });
               item.FloorList = db.Floors.Select(r => new SelectListItem
               {
                   Value = r.FloorID.ToString(),
                   Text = r.FloorName
               });
               item.LocationList = db.Locations.Select(r => new SelectListItem
               {
                   Value = r.LocationID.ToString(),
                   Text = r.LocationName
               });

               var floor = db.Floors.Where(m => m.FloorID.Equals(id)).FirstOrDefault();
               item.BuildingID = floor.BuildingID;
               item.FloorID = floor.FloorID;
               item.LocationID = floor.LocationID;


               return View(item);
           }
       }
       [HttpPost]
       public ActionResult FacilityUnitsCreate(Unit item)
       {
           db.Units.Add(item);
           db.SaveChanges();
           return RedirectToAction("FacilityUnits/"+item.FloorID);
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
       public ActionResult FacilityUnitsEdit(int id)
       {
           if (Session["user"] == null)
           {

               return RedirectToAction("Login", "Home");
           }
           else
           {
               CreateUnit item = new CreateUnit();

               item.BaseSupervisorList = db.SupervisorDetails.Where(m => m.SupervisorLevel.Equals("BaseSupervisor")).Select(r => new SelectListItem
               {
                   Value = r.UserID.ToString(),
                   Text = r.User.UserName
               });
               item.BuildingList = db.Buildings.Select(r => new SelectListItem
               {
                   Value = r.BuildingID.ToString(),
                   Text = r.BuildingName
               });

               item.FacilityList = db.Facilities.Select(r => new SelectListItem
               {
                   Value = r.FacilityID.ToString(),
                   Text = r.FacilityName
               });
               item.FloorList = db.Floors.Select(r => new SelectListItem
               {
                   Value = r.FloorID.ToString(),
                   Text = r.FloorName
               });
               item.LocationList = db.Locations.Select(r => new SelectListItem
               {
                   Value = r.LocationID.ToString(),
                   Text = r.LocationName
               });

               var old_item = db.Units.Where(m => m.UnitID.Equals(id)).FirstOrDefault();
               item.BaseSupervisorID = old_item.BaseSupervisorID;
               item.BuildingID = old_item.BuildingID;
               item.FacilityID = old_item.FacilityID;
               item.FloorID = old_item.FloorID;
               item.LocationID = old_item.LocationID;
               item.UnitID = old_item.UnitID;
               item.UnitName = old_item.UnitName;
               item.Wing = old_item.Wing;
               return View(item);
           }
       }

        [HttpPost]
        public ActionResult FacilityUnitsEdit(CreateUnit old_item)
       {
           var item = db.Units.Where(m => m.UnitID.Equals(old_item.UnitID)).FirstOrDefault();

           item.BaseSupervisorID = old_item.BaseSupervisorID;
           item.BuildingID = old_item.BuildingID;
           item.FacilityID = old_item.FacilityID;
           item.FloorID = old_item.FloorID;
           item.LocationID = old_item.LocationID;
           
           item.UnitName = old_item.UnitName;
           item.Wing = old_item.Wing;

           db.SaveChanges();
           return RedirectToAction("FacilityUnits/" + old_item.FloorID);
       }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult FacilityUnitsDelete(int id)
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                var item = db.Units.Where(m => m.UnitID.Equals(id)).FirstOrDefault();
                db.Units.Remove(item);
                db.SaveChanges();

                return RedirectToAction("FacilityUnits/" + item.FloorID);
            }
        }
        [HttpPost]
        public ActionResult Users(string UserID)
        {

            AdminEntities entities = new AdminEntities();
            var customers = entities.Users.Where(m => m.UserID.Equals(UserID)).ToList();
            if (customers.Count != 0)
            {
                return View(customers);
            }
            customers = entities.Users.Where(m => m.UserName.Equals(UserID)).ToList();

            if (customers.Count != 0)
            {
                return View(customers);
            }
            customers = entities.Users.Where(m => m.UserPhoneNo.Equals(UserID)).ToList();
            if (customers.Count != 0)
            {
                return View(customers);
            }
            return View(customers);
        }
        [HttpPost]
        public ActionResult Facilities(string UserID)
        {

            AdminEntities entities = new AdminEntities();
            
            var customers = entities.Facilities.Where(m => m.FacilityName.Equals(UserID)).ToList();
            if (customers.Count != 0)
            {
                return View(customers);
            }
            try
            {
                int id = Convert.ToInt32(UserID);
                customers = entities.Facilities.Where(m => m.FacilityID.Equals(UserID)).ToList();


            }
            catch { }
            if (customers.Count != 0)
            {
                return View(customers);
            }

            return View(customers);
        }
        [HttpPost]
        public ActionResult Buildings(string UserID)
        {

            AdminEntities entities = new AdminEntities();
            
            var customers = entities.Buildings.Where(m => m.BuildingName.Equals(UserID)).ToList();
            if (customers.Count != 0)
            {
                return View(customers);
            }
            try
            {
                int id = Convert.ToInt32(UserID);
                customers = entities.Buildings.Where(m => m.BuildingID.Equals(id)).ToList();

            }
            catch { }
            if (customers.Count != 0)
            {
                return View(customers);
            }

            return View(customers);
        }
        [HttpPost]
        public ActionResult Floors(string UserID)
        {

            AdminEntities entities = new AdminEntities();
            
            var customers = entities.Floors.Where(m => m.FloorName.Equals(UserID)).ToList();
            if (customers.Count != 0)
            {
                return View(customers);
            }
            try
            {
                int id = Convert.ToInt32(UserID);
                customers = entities.Floors.Where(m => m.FloorID.Equals(id)).ToList();
            }

            catch { }
            if (customers.Count != 0)
            {
                return View(customers);
            }

            return View(customers);
        }
        [HttpPost]
        public ActionResult Locations(string UserID)
        {

            AdminEntities entities = new AdminEntities();
           
            var customers = entities.Locations.Where(m => m.LocationName.Equals(UserID)).ToList();
            if (customers.Count != 0)
            {
                return View(customers);
            }
            customers = entities.Locations.Where(m => m.LocationCountry.Equals(UserID)).ToList();
            if (customers.Count != 0)
            {
                return View(customers);
            }
            customers = entities.Locations.Where(m => m.LocationZipCode.Equals(UserID)).ToList();
            if (customers.Count != 0)
            {
                return View(customers);
            }
            customers = entities.Locations.Where(m => m.LocationCity.Equals(UserID)).ToList();
            if (customers.Count != 0)
            {
                return View(customers);
            }
            try
            {
                int id = Convert.ToInt32(UserID);
                customers = entities.Locations.Where(m => m.LocationID.Equals(id)).ToList();

            }
            catch { }
            
            if (customers.Count != 0)
            {
                return View(customers);
            }

            return View(customers);
        }
        
    }
}