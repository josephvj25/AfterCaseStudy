﻿using FacilitesFeedbackBackendV1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FacilitesFeedbackBackendV1.Models
{
    public class FeedbacksController : Controller
    {

        FeedbackFacilityEntities db = new FeedbackFacilityEntities();
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            if (Session["user"] == null)
                filterContext.Result = new RedirectResult("~/Home/Index");
            else
            {
                var id = Session["user"].ToString().Trim();
                if (db.Users.Where(m => m.UserID.Equals(id)).FirstOrDefault().UserRole != "BaseSupervisor")
                {
                    filterContext.Result = new RedirectResult("~/Home/Index");
                }
                else
                    base.OnActionExecuting(filterContext);
            }
        }

        [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        // GET: Feedbacks
        public ActionResult Index()
        {
            string id;
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {

                id = Session["user"].ToString().Trim();

            }

            var units = db.Units.Where(m => m.BaseSupervisorID.Equals(id));
            var ratings = db.Ratings.ToList();
            double avgrating = 0;


            var rating = new List<double>();
            var UnitName = new List<string>();
            var FloorName = new List<string>();
            var BuildingName = new List<string>();
            var LocationName = new List<string>();
            var Wing = new List<string>();
            var UnitID = new List<int>();

            foreach (var u in units)
            {
                int ratingtotal = 0;
                int ratingcount = 0;

                foreach (var r in ratings)
                {

                    if (r.UnitID.Equals(u.UnitID))
                    {
                        ratingcount++;
                        ratingtotal += Convert.ToInt32(r.Rating1);


                    }

                }
                if (ratingcount != 0)
                {
                    avgrating = Convert.ToDouble(ratingtotal) / Convert.ToDouble(ratingcount);
                    rating.Add(avgrating);
                    UnitName.Add(u.UnitName);
                    UnitID.Add(u.UnitID);
                    Wing.Add(u.Wing);
                    string floor = (db.Floors.Where(m => m.FloorID.Equals(u.FloorID)).FirstOrDefault()).FloorName;
                    FloorName.Add(floor);
                    string bul = (db.Buildings.Where(m => m.BuildingID.Equals(u.BuildingID)).FirstOrDefault()).BuildingName;
                    BuildingName.Add(bul);
                    string loc = (db.Locations.Where(m => m.LocationID.Equals(u.LocationID)).FirstOrDefault()).LocationName;
                    LocationName.Add(loc);

                }
                avgrating = 0;
            }


            @ViewBag.Ratings = rating;
            @ViewBag.UnitNames = UnitName;
            @ViewBag.UnitIDs = UnitID;
            @ViewBag.FloorNames = FloorName;
            @ViewBag.BuildingNames = BuildingName;
            @ViewBag.LocationNames = LocationName;
            @ViewBag.Wings = Wing;
            return View();

        }
    }
        
}
    


        //public ActionResult OldIndex()
        //{

    //        NorthwindEntities3 db = new NorthwindEntities3();

    //        double fb11Count = db.Feedbacks.Where(c => c.FeedbackRating1 == 1).Count();
    //        double fb12Count = db.Feedbacks.Where(c => c.FeedbackRating1 == 2).Count();
    //        double fb13Count = db.Feedbacks.Where(c => c.FeedbackRating1 == 3).Count();
    //        double fb14Count = db.Feedbacks.Where(c => c.FeedbackRating1 == 4).Count();
    //        double fb15Count = db.Feedbacks.Where(c => c.FeedbackRating1 == 5).Count();

    //        double fb1mean = ((fb11Count * 1) + (fb12Count * 2) + (fb13Count * 3) + (fb14Count * 4) + (fb15Count * 5)) / (fb11Count + fb12Count + fb13Count + fb14Count + fb15Count); 

    //        double fb21Count = db.Feedbacks.Where(c => c.FeedbackRating2 == 1).Count();
    //        double fb22Count = db.Feedbacks.Where(c => c.FeedbackRating2 == 2).Count();
    //        double fb23Count = db.Feedbacks.Where(c => c.FeedbackRating2 == 3).Count();
    //        double fb24Count = db.Feedbacks.Where(c => c.FeedbackRating2 == 4).Count();
    //        double fb25Count = db.Feedbacks.Where(c => c.FeedbackRating2 == 5).Count();

    //        double fb2mean = ((fb21Count * 1) + (fb22Count * 2) + (fb23Count * 3) + (fb24Count * 4) + (fb25Count * 5)) / (fb21Count + fb22Count + fb23Count + fb24Count + fb25Count);


    //        double fb31Count = db.Feedbacks.Where(c => c.FeedbackRating3 == 1).Count();
    //        double fb32Count = db.Feedbacks.Where(c => c.FeedbackRating3 == 2).Count();
    //        double fb33Count = db.Feedbacks.Where(c => c.FeedbackRating3 == 3).Count();
    //        double fb34Count = db.Feedbacks.Where(c => c.FeedbackRating3 == 4).Count();
    //        double fb35Count = db.Feedbacks.Where(c => c.FeedbackRating3 == 5).Count();

    //        double fb3mean = ((fb31Count * 1) + (fb32Count * 2) + (fb33Count * 3) + (fb34Count * 4) + (fb35Count * 5)) / (fb31Count + fb32Count + fb33Count + fb34Count + fb35Count);

    //        var fb1remarks = db.Feedbacks.Where(c => c.FeedbackRating1Remarks != null).Select(c => c.FeedbackRating1Remarks).ToList();
    //        var fb2remarks = db.Feedbacks.Where(c => c.FeedbackRating2Remarks != null).Select(c => c.FeedbackRating2Remarks).ToList();
    //        var fb3remarks = db.Feedbacks.Where(c => c.FeedbackRating3Remarks != null).Select(c => c.FeedbackRating3Remarks).ToList();


    //        var consolidatedFeedback = new ConsolidatedFeedback {
    //            Fb11Count=(int)fb11Count,
    //            Fb12Count=(int)fb12Count,
    //            Fb13Count=(int)fb13Count,
    //            Fb14Count=(int)fb14Count,
    //            Fb15Count=(int)fb15Count,

    //            Fb21Count=(int)fb21Count,
    //            Fb22Count=(int)fb22Count,
    //            Fb23Count=(int)fb23Count,
    //            Fb24Count=(int)fb24Count,
    //            Fb25Count=(int)fb25Count,

    //            Fb31Count=(int)fb31Count,
    //            Fb32Count=(int)fb32Count,
    //            Fb33Count=(int)fb33Count,
    //            Fb34Count=(int)fb34Count,
    //            Fb35Count=(int)fb35Count,


    //            Fb1Mean=fb1mean,
    //            Fb2Mean=fb2mean,
    //            Fb3Mean=fb3mean,

    //            Fb1Remarks=fb1remarks,
    //            Fb2Remarks=fb2remarks,
    //            Fb3Remarks=fb3remarks
    //        }; 

    //        return View(consolidatedFeedback);
    //    }
//    //}
//}