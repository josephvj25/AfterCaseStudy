﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Routing;
using FacilitesFeedbackBackendV1.Models;


namespace FacilitesFeedbackBackendV1.Models
{
    public class HomeController : Controller
    {
        FeedbackFacilityEntities db = new FeedbackFacilityEntities();
        
        [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult Login()
        {
            
            if (Session["user"] != null)
                return RedirectToAction("Index");
            else
                return View();
            
            
               
            
        }

        [HttpPost]
        public ActionResult Login(LoginUser user)
        {
            if (ModelState.IsValid)
            {
                var u = db.Users.Where(m => m.UserID.Equals(user.UserID) && m.UserPhoneNo.Equals(user.Password)).FirstOrDefault();
                @ViewBag.Message = "";
                if (u != null)
                {
                    Session["user"] = user.UserID;
                    return RedirectToAction("Index");
                }
                else
                {
                    @ViewBag.Message = "User Name or Password is incorrect.";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult Index()
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login");
            }
            else
            {
                var u = Session["user"].ToString().Trim();
                var userrole = db.Users.Where(m => m.UserID.Equals(u)).FirstOrDefault().UserRole;
                if(userrole == "Admin" )
                {
                    return RedirectToAction("Index", "Admin");
                }
            }
            return View();
        }

        
    

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Logout()
        {
            Session.Abandon();
            Session.Clear();
            Session.RemoveAll();
            System.Web.Security.FormsAuthentication.SignOut();
            
            return RedirectToAction("Login");
        }

        public JsonResult GetChart()
        {
            string id;
            if(Session["user"]==null)
            {
                return Json("Please Login", JsonRequestBehavior.AllowGet);
            }
            else
            {
                id = Session["user"].ToString().Trim();
            }
            JsonLineChart linechart = new JsonLineChart();
            

            AdminEntities db = new AdminEntities();
            var units = db.Units.Where(m=>m.BaseSupervisorID.Equals(id));
            
            var ratings = db.Ratings.ToList();
            
            //List<Rating> ourrating = new List<Rating>();

            double avgrating = 0;

            JsonLineChartDataset ds = new JsonLineChartDataset();
            Random color = new Random();

            ds.fillColor = "rgba(" + color.Next(50, 220).ToString().Trim() + ",123,133,0.4)";
            ds.pointColor = "rgba(220,220,220,1)";
            ds.strokecolor = "rgba(220,220,220,1)";
            ds.pointStrokeColor = "#fff";
            ds.data = new List<double>();
            
            foreach(var u in units)
            {
                int ratingtotal = 0;
                int ratingcount = 0;
                
                foreach (var r in ratings)
                {
                     
                    if(r.UnitID.Equals(u.UnitID))
                    {
                        ratingcount++;
                        ratingtotal += Convert.ToInt32(r.Rating1);
                        
                       
                    }

                }
                if(ratingcount!=0)
                {
                    avgrating = Convert.ToDouble(ratingtotal) / Convert.ToDouble(ratingcount);
                    ds.data.Add(avgrating);

                    //ds.data= new List<int> { 65, 54, 30, 81, 56, 55, 40 };
                    linechart.labels.Add(u.UnitName);
                    
                }
                avgrating = 0;
            }
            linechart.datasets.Add(ds);

            
            
            return Json(linechart, JsonRequestBehavior.AllowGet);
        }
       
    }
}


