﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using FacilitesFeedbackBackendV1.Models;

namespace FacilitesFeedbackBackendV1.Models
{
    public class SuggestionsController : Controller
    {
        
        private FeedbackFacilityEntities db = new FeedbackFacilityEntities();
        
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            if (Session["user"] == null)
                filterContext.Result = new RedirectResult("~/Home/Index");
            else
            {
                var id = Session["user"].ToString().Trim();
                if (db.Users.Where(m => m.UserID.Equals(id)).FirstOrDefault().UserRole != "BaseSupervisor")
                {
                    filterContext.Result = new RedirectResult("~/Home/Index");
                }
                else
                    base.OnActionExecuting(filterContext);
            }
        }



        [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult Index()
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            return View(db.ProcDisplaySugSupervisor(Session["user"].ToString()).ToList());
        }
        [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult Details(int id)
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                db.ProcUpdateSugRead(id);
                return View(db.ProcDisplaySugDetails(id).FirstOrDefault());
            }
        }

       [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult Approve(int id)//suggetion object
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                db.ProcUpdateSugTaken(id);

                return RedirectToAction("Index");
            }
        }

       [HttpPost, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult Reject(Suggestion s)//suggetion objct
        {
            if (Session["user"] == null)
            {

                return RedirectToAction("Login", "Home");
            }
            else
            {
                db.ProcUpdateSugRejected(s.SuggestionID, s.RejectionRemarks);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
