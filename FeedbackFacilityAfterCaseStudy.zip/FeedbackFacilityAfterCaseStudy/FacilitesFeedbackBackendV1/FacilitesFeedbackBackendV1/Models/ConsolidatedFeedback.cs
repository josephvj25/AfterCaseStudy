﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FacilitesFeedbackBackendV1.Models
{
    public class ConsolidatedFeedback
    {
        public int Fb11Count { get; set; }
        public int Fb12Count { get; set; }
        public int Fb13Count { get; set; }
        public int Fb14Count { get; set; }
        public int Fb15Count { get; set; }

        public int Fb21Count { get; set; }
        public int Fb22Count { get; set; }
        public int Fb23Count { get; set; }
        public int Fb24Count { get; set; }
        public int Fb25Count { get; set; }

        public int Fb31Count { get; set; }
        public int Fb32Count { get; set; }
        public int Fb33Count { get; set; }
        public int Fb34Count { get; set; }
        public int Fb35Count { get; set; }

        public double Fb1Mean { get; set; }
        public double Fb2Mean { get; set; }
        public double Fb3Mean { get; set; }

        public List<string> Fb1Remarks { get; set; }
        public List<string> Fb2Remarks { get; set; }
        public List<string> Fb3Remarks { get; set; }
    }
}