﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FacilitesFeedbackBackendV1.Models
{
    public class CreateBuilding
    {
  
        public CreateBuilding()
        {
            this.Floors = new HashSet<Floor>();
            this.Units = new HashSet<Unit>();
            this.SupervisorDetails = new HashSet<SupervisorDetail>();
        }
        
        public int BuildingID { get; set; }
        [Required(ErrorMessage = "Enter Building Name")]
        public string BuildingName { get; set; }
        public int LocationID { get; set; }
        public IEnumerable<SelectListItem> LocationList { get; set; }
    
        public virtual Location Location { get; set; }
        public virtual ICollection<Floor> Floors { get; set; }
        public virtual ICollection<Unit> Units { get; set; }
        public virtual ICollection<SupervisorDetail> SupervisorDetails { get; set; }
    }
    public class CreateUnit
    {

         public CreateUnit()
        {
            this.Ratings = new HashSet<Rating>();
        }
    
        public int UnitID { get; set; }
        [Required(ErrorMessage = "Enter Unit Name")]
        public string UnitName { get; set; }
        [Required(ErrorMessage = "Enter the Wing")]
        public string Wing { get; set; }
        public int FacilityID { get; set; }
        public int BuildingID { get; set; }
        public int FloorID { get; set; }
        public int LocationID { get; set; }
        public string BaseSupervisorID { get; set; }

        public IEnumerable<SelectListItem> LocationList { get; set; }
        public IEnumerable<SelectListItem> FacilityList { get; set; }
        public IEnumerable<SelectListItem> BuildingList { get; set; }
        public IEnumerable<SelectListItem> FloorList { get; set; }
        public IEnumerable<SelectListItem> BaseSupervisorList { get; set; }
    
        public virtual Building Building { get; set; }
        public virtual Facility Facility { get; set; }
        public virtual Floor Floor { get; set; }
        public virtual Location Location { get; set; }
        public virtual ICollection<Rating> Ratings { get; set; }
        public virtual User User { get; set; }
    }
    public class CreateFloor
    {

         public CreateFloor()
        {
            this.Units = new HashSet<Unit>();
            this.SupervisorDetails = new HashSet<SupervisorDetail>();
        }
    
        public int FloorID { get; set; }
        [Required(ErrorMessage = "Enter Floor Name")]
        public string FloorName { get; set; }
        public int BuildingID { get; set; }
        public int LocationID { get; set; }
        [Required(ErrorMessage = "Enter the Wing List")]
        public string Wings { get; set; }
        public IEnumerable<SelectListItem> LocationList { get; set; }
        public IEnumerable<SelectListItem> BuildingList { get; set; }

    
        public virtual Building Building { get; set; }
        public virtual Location Location { get; set; }
        public virtual ICollection<Unit> Units { get; set; }
        public virtual ICollection<SupervisorDetail> SupervisorDetails { get; set; }
    }
    
     
}

