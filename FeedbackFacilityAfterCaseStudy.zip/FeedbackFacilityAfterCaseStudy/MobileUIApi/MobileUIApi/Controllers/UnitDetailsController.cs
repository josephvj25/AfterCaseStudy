﻿using MobileUIApi.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MobileUIApi.Controllers
{
   
        public class UnitInfo
        {
            public Int16 Id { get; set; } 
            public String wing { get; set; }
        }
     
        public class UnitDetailsController : ApiController
        {
            
        private FeedbackFacilityEntities db = new FeedbackFacilityEntities();
        
    
            [HttpGet]

        public IEnumerable<ProcSelectUnit_Result> Unit([FromUri]UnitInfo Info)
            {
                
                var item = db.ProcSelectUnit(Info.Id,Info.wing);
                return item;
            }
        }
    }

