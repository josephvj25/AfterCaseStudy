﻿using MobileUIApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MobileUIApi.Controllers
{
    public class UserController : ApiController
    {
        private FeedbackFacilityEntities db = new FeedbackFacilityEntities();



        [HttpGet]
        public string CheckUser(string Id,string Pass)
        {
            var item = db.Users.Where(m => (m.UserID.Equals(Id)&&m.UserPhoneNo.Equals(Pass))).FirstOrDefault();
            if (item is User)
            {
                return "1";
            }
            else
                return "0";
        }





        [HttpPost]
        public void NewUser([FromBody]User iUser)
        {

            iUser.UserRole = "Associate";
            db.Users.Add(iUser);

            db.SaveChanges();
        }

        //[HttpPost()]
        //public IHttpActionResult Post(Product product)
        //{
        //    IHttpActionResult ret = null;
        //    if (Add(product))
        //    {
        //        ret = Created<Product>(Request.RequestUri +
        //             product.ProductId.ToString(), product);
        //    }
        //    else
        //    {
        //        ret = NotFound();
        //    }
        //    return ret;
        //}


        
    }
}
