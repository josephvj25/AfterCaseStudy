﻿using MobileUIApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MobileUIApi.Controllers
{
    public class LocationDetailsController : ApiController
    {
        private FeedbackFacilityEntities db = new FeedbackFacilityEntities();



        [HttpGet]
        
        public IEnumerable<String> City()
        {
            var item = db.ProcSelectCity();
            return item;
        }

        [HttpGet]
        public IEnumerable<ProcSelectLocation_Result> Location()
        {
            var item = db.ProcSelectLocation();
            return item;
        }

        [HttpGet]
        public IEnumerable<ProcSelectBuliding_Result> Building(int Id)
        {
            var item = db.ProcSelectBuliding(Id);
            return item;
        }

        [HttpGet]
        public System.Data.Entity.Core.Objects.ObjectResult<string> Wing(int Id)
        
        
        {
            var item = db.ProcSelectWing(Id);
            return item;
        }


        [HttpGet]
        [Route("api/LocationDetails/Facility/{Id}")]
        public string Facility(int Id)
        {
            var item = db.Units.Where(m => m.UnitID.Equals(Id)).FirstOrDefault();

            return item.FacilityID.ToString();
        }​

        [HttpGet]
        public IEnumerable<ProcSelectFloor_Result> Floor(int Id)
        {
            var item = db.ProcSelectFloor(Id);
            return item;
        }

        [HttpGet]
        [Route("api/LocationDetails/Unit/{Id}/{wing}")]
        public IEnumerable<ProcSelectUnit_Result> Unit(int Id, string wing)
        {
            var item = db.ProcSelectUnit(Id, wing);
            return item;
        }
    }
}
