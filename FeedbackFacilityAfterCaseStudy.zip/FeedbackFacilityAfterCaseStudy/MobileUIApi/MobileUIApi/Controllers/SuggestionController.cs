﻿using MobileUIApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MobileUIApi.Controllers
{
    public class SuggestionController : ApiController
    {

        private FeedbackFacilityEntities db = new FeedbackFacilityEntities();

        //[HttpGet]
        //public IEnumerable<ProcFeedbackHistory_Result> SuggestionHistory(string id)
        //{
        //    var item = db.ProcFeedbackHistory(id);
        //    return item;
        //}

        [HttpPost]
        public void NewSuggestion(Suggestion iSuggestion)
        {

            iSuggestion.SuggestionDate = DateTime.Now;
            iSuggestion.SuggestionStatus = "Unread";
            db.Suggestions.Add(iSuggestion);
            db.SaveChanges();
        }


    }
}
