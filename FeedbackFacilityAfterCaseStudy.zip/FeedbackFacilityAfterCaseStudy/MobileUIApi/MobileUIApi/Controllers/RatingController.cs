﻿using MobileUIApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MobileUIApi.Controllers
{
    public class RatingController : ApiController
    {
        private FeedbackFacilityEntities db = new FeedbackFacilityEntities();

        [HttpGet]
        public IEnumerable<ProcDisplayQus_Result> QuestionsList(int id)
        {
            var result = db.ProcDisplayQus(id);
            //var result = db.Questions.Where(m => m.FacilityID.Equals(id)).ToList;
            return result;
        }

        [HttpPost]
        public void NewRating(Rating iRating)
        {

            iRating.RatingDate = DateTime.Now;
            db.Ratings.Add(iRating);
            db.SaveChanges();
        }
    }
}
