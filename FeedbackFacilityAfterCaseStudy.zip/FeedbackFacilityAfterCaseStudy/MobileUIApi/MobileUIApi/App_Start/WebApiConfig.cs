﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace MobileUIApi
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes

            config.MapHttpAttributeRoutes();
            config.Routes.MapHttpRoute(
                      name: "CheckUserApi",
                      routeTemplate: "api/{controller}/{action}/{Id}/{Pass}"

                  );


            config.Routes.MapHttpRoute(
                      name: "UnitApi",
                      routeTemplate: "api/{controller}/{action}/{Id}/{wing}"

                  );

            

            

            config.Routes.MapHttpRoute(
           name: "ActionApi",
           routeTemplate: "api/{controller}/{action}/{id}",
           defaults: new { id = RouteParameter.Optional }
       );

            


            

           


        }
    }
}
