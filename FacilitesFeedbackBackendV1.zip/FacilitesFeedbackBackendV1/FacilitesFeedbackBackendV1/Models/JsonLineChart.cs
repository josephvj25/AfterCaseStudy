﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FacilitesFeedbackBackendV1.Models
{
    public class JsonLineChartDataset
    {
        public JsonLineChartDataset()
        {
            data = new List<double>();
        }
        public string fillColor { get; set; }
        public string strokecolor { get; set; }
        public string pointColor { get; set; }
        public string pointStrokeColor { get; set; }
        public List<double> data { get; set; }

    }
    public class JsonLineChart
    {
        public JsonLineChart()
        {
            labels = new List<string>();
            datasets = new List<JsonLineChartDataset>();
        }
        public List<string> labels { get; set; }
        public List<JsonLineChartDataset> datasets { get; set; }
    }
}