﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace FacilitesFeedbackBackendV1.Models
{
    public class LoginUser
    {
        [Required(ErrorMessage="Enter User ID")]
        public string UserID { get; set; }
        [Required(ErrorMessage="Enter password")]
        public string Password { get; set; }
    }
}
